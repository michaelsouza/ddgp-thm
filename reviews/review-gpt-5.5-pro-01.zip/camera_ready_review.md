# Camera-ready review of `main_monolithic.tex`

## Verdict

**Do not submit the current PDF as-is.** The article compiles and the rendered layout is broadly clean, but it is **not camera-ready** because all bibliography citations are unresolved and no bibliography is printed. This is a hard submission blocker.

## Build and preflight results

- Source: `main_monolithic.tex`
- PDF produced: `main_monolithic.pdf`
- Page count: 15
- PDF opens successfully and is text-based, not scanned.
- Fonts are embedded.
- No obvious clipping or page-layout failure was visible in the rendered pages.
- The bibliography file `references.bib` is missing, so BibTeX cannot run.
- The PDF contains unresolved citation markers (`[?]`).
- The references section is absent because no `.bbl` file was generated.

## Critical blockers

### 1. Missing bibliography

The source ends with:

```tex
\bibliographystyle{plain}
\bibliography{references}
```

but `references.bib` was not present in the submission folder. The build log reports no `.bbl` file and 31 unresolved citation occurrences.

Unique missing citation keys:

- `abud2018k`
- `abud2024impossible`
- `cassioli2015discretization`
- `goncalves2021new`
- `lavor2012discretizable`
- `lavor2021optimality`
- `liberti2008branch`
- `liberti2011number`
- `liberti2013counting`
- `liberti2014number`
- `mucherino2012discretizable`
- `mucherino2012exploiting`
- `mucherino2020analysis`

**Required action:** add `references.bib`, or replace the BibTeX block with a complete `thebibliography` environment, then rerun LaTeX/BibTeX/LaTeX/LaTeX until all citations resolve.

### 2. Venue template not applied

The article currently uses:

```tex
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
```

This is fine for a preprint but not necessarily camera-ready for a conference or journal. If the venue has a required class file, bibliography style, page limit, line numbering policy, or author-anonymity policy, those need to be applied before submission.

### 3. Source archive leaks local paths

The source contains comments such as:

```tex
% === BEGIN INPUT: /home/michael/gitrepos/ddgp-thm/article/sections/introduction.tex ===
```

These are not visible in the PDF, but they should be removed before submitting source files.

### 4. Proof completeness depends on a strong hypothesis

The theorem is correct as a conditional theorem under the stated mirror-separated assumption, but the paper currently does not fully prove that mirror separation holds generically for the class of templates under consideration. The current “Genericity and probability one” remark says this holds when the relevant algebraic equalities define a proper exceptional set. For a strong camera-ready submission, the paper should either:

- prove that properness for the templates covered by the theorem; or
- explicitly present the theorem as conditional on mirror separation and moderate the claims in the abstract, introduction, and conclusion.

## Mathematical and exposition issues to fix before submission

### Zero-violation preservation lemma

The proof of Lemma 2 is the most sensitive part of the paper. It uses block reflections grouped by mirror clique and then concludes that the accumulated branch mask gives the code transformation `s \oplus h`. The intended idea is good, but the proof needs to be phrased carefully because DDGP reflections are dynamic BP sign-cover operations, not generally commuting fixed Euclidean reflections.

Minimum fixes:

- Define `\mathcal{G}_C` before using it.
- Replace the undefined symbol `\mathcal{V}` with `V`.
- Avoid the undefined notation `v_C` / `v_{C_i}`.
- State explicitly that the local base edges are included in `F` and are what make each block a valid BP sign-cover operation.
- Add a short block-admissibility lemma: if a support is downstream of mirror clique `C` and every crossed active/base edge has fixed endpoint in `C`, then reflection through `aff(C)` realizes the corresponding branch-code mask and preserves all active lengths.

### Counting convention

The paper counts branch-code realizations relative to the fixed seed clique. It should explicitly state whether realizations are counted as fixed-coordinate branch realizations or modulo Euclidean congruence. I added a low-risk sentence in the edited source clarifying that counts are branch-code counts relative to the fixed seed clique.

### Example wording

The example says the first clique “generates `v_3` and the free vertex `v_7`,” but the base generator matrices are only over the constrained set `B_c`. This is logically fine, but the wording can confuse readers. I changed it in the low-risk edit to say that the clique is the predecessor clique for both vertices, while only `v_3` contributes to constrained masks.

### Overclaiming in abstract/conclusion

The introduction calls the result a “complete algebraic rank-count theory,” and the conclusion says the linear structure “completely determines the generic solution count.” Given the theorem’s reliance on mirror separation, these claims should be softened unless a genericity/proper-exceptional-set proof is added.

## Low-risk edits applied in `main_camera_ready_lowrisk.tex`

I prepared a conservative source revision that:

- removes local source-path comments;
- adds T1 font encoding, Latin Modern, and `microtype`;
- adds PDF metadata and colored internal/citation links through `hyperref`;
- clarifies the branch-code counting convention;
- defines `\mathcal{G}_C`;
- fixes `\mathcal{V}` to `V`;
- replaces undefined `v_C` notation by `r(C)`;
- uses `\oplus` consistently for affine cosets over `\mathbb{F}_2`;
- moderates one conclusion claim;
- cleans one confusing example sentence.

This revision compiles to a 15-page PDF and has embedded fonts and valid PDF metadata. It still has unresolved citations because the bibliography file is missing.

## Final camera-ready checklist

Before submission:

1. Add `references.bib` or a complete bibliography environment.
2. Rebuild until no citation warnings remain.
3. Apply the target venue template and bibliography style.
4. Decide whether to strengthen or explicitly conditionalize the mirror-separation/genericity claim.
5. Tighten the zero-violation preservation proof as described above.
6. Remove local-path comments from the source archive.
7. Verify final PDF after applying the venue template: page count, margins, fonts, figures, tables, references, metadata.

# Revisão matemática da versão atualizada

## Veredito

A versão atualizada está substancialmente mais fluida e o arquivo compila corretamente com a bibliografia fornecida. Do ponto de vista matemático, a estrutura principal está em boa forma: as definições de `Fix`, `Cone`, `B_c`, `B_f`, as matrizes `M` e `V`, o cálculo do exemplo e a fórmula de posto estão coerentes.

Eu **não submeteria exatamente o TeX atual sem pequenas correções formais**, porque algumas afirmações ficaram mais fortes do que os enunciados provam e há uma imprecisão no Lema de admissibilidade de blocos. Preparei um patch compacto que corrige esses pontos sem alterar o resultado principal, o exemplo, o número de páginas ou a estrutura do artigo.

## Diagnóstico de compilação

- `pdflatex` + BibTeX + duas passagens finais de `pdflatex`: OK.
- Citações indefinidas: nenhuma na compilação final.
- Referências internas indefinidas: nenhuma na compilação final.
- PDF da versão enviada: 17 páginas.
- PDF com o patch compacto: 17 páginas.
- Fontes: embutidas/subsetadas.
- Renderização visual: sem clipping, sobreposição óbvia, caixas pretas ou glifos quebrados.

## Pontos matemáticos que eu corrigiria antes da submissão

### 1. Qualificação do resultado no resumo e na introdução

No resumo, a frase final afirma que os códigos viáveis “formam um espaço afim sobre \(\mathbb F_2\)” sem repetir as hipóteses de separação por espelhos e não-vacuidade. O Teorema principal, porém, assume explicitamente \(\Xi\ne\varnothing\) e parâmetros mirror-separated. A introdução também fala em “complete algebraic rank-count theory” e em fórmula “weight-independent” de modo um pouco forte demais.

Referências no TeX enviado: linhas 50, 64, 70 e 96.

Correção recomendada: qualificar as afirmações como válidas “under mirror-separated parameters and assuming nonemptiness” ou “under the stated hypotheses”. Isso evita que o leitor espere que a fórmula detecte o caso \(\Xi=\varnothing\). A fórmula de posto conta o coset gerado a partir de uma solução de referência; ela não é, sozinha, um teste de viabilidade.

### 2. Definição de instância Combinatorial DDGP e tratamento da clique inicial

Na seção de definições, o texto diz que cada \(U_i\) tem tamanho \(K\), mas não reitera que cada \(U_i\) induz uma clique prescrita. Para a classe Combinatorial DDGP, isso deve aparecer na parte formal, não apenas na motivação.

Além disso, a linha que define \(E_D\) apenas como “discretization edges induced by the predecessor relation” deixa ambíguo o que acontece com as arestas da clique inicial \(V_0\). Como \(E_P=E\setminus E_D\), as arestas da clique inicial poderiam ser classificadas erroneamente como pruning edges se \(E_D\) não as incluir ou se elas não forem explicitamente omitidas por estarem fixas.

Referências no TeX enviado: linhas 102 e 132.

Correção recomendada: definir
\[
E_D=\binom{V_0}{2}\cup\{\{u,i\}:i>K,\ u\in U_i\},
\]
ou dizer explicitamente que as distâncias da clique inicial são fixas e não entram em \(E_P\). O patch usa a primeira opção. Isso não muda as matrizes do exemplo, porque a aresta \(\{v_1,v_2\}\) nunca cruza suportes de geradores.

### 3. Parágrafo sobre máscaras duplicadas e rótulos de espelho

O parágrafo sobre base generators diz que duas operações com a mesma branch mask, mas espelhos diferentes, podem produzir “distinct spatial coordinates”. Isso é perigoso: para uma semente fixa e uma codificação de ramos fixa, a branch mask determina um branch code final, e o branch code determina a incorporação lateration correspondente. O que realmente difere entre colunas duplicadas não é o branch code final, mas o certificado algébrico e o padrão de violações rotuladas usado para provar preservação.

Referências no TeX enviado: linhas 232–237.

Correção recomendada: trocar esse parágrafo por uma formulação mais precisa: máscaras iguais podem ter apresentações rotuladas diferentes, e os rótulos não devem ser quocientados porque a matriz \(V\) testa violações em relação ao espelho do certificado.

### 4. Afirmação forte demais sobre cancelamento de violações

A seção “Labeled Violations” afirma que violações da mesma aresta “only cancel” quando ocorrem no mesmo espelho. Como princípio geométrico absoluto, isso é forte demais: composições de reflexões em espelhos diferentes podem preservar uma distância em configurações especiais. O arcabouço do artigo escolhe, corretamente, tratar tais coincidências como excepcionais e excluí-las via mirror separation.

Referência no TeX enviado: linha 289.

Correção recomendada: escrever que o certificado algébrico permite cancelamentos apenas dentro do mesmo rótulo de espelho, enquanto coincidências entre espelhos distintos são tratadas como excepcionais e excluídas pela hipótese de mirror separation.

### 5. Lema de admissibilidade de blocos: restringir ao subsistema ativo

Este é o ponto técnico mais importante. O Lema de admissibilidade define coordenadas \(y_i\) para todos os vértices e a prova afirma que, se \(i\notin S\) e \(i\notin C\), nenhum predecessor de \(i\) pode estar em \(S\). A justificativa usa a aresta \(\{u,i\}\in E_D[L]\). Isso só é automaticamente verdadeiro quando \(i\in L\). Para vértices livres fora de \(L\), pode haver predecessores em \(S\), e a aresta correspondente não pertence a \(E_D[L]\).

Referências no TeX enviado: linhas 409–430.

Correção recomendada: enunciar e provar o lema “on the active subsystem induced by \(L\)”. Isso é suficiente para o teorema, porque \(\Xi_F\) só testa arestas em \(F\). Vértices livres fora de \(L\) podem ser estendidos por suas próprias escolhas de ramo depois; eles não precisam permanecer fixos no bloco local usado para provar preservação das arestas ativas.

### 6. Espaço de parâmetros: colisão de notação \(\mathbb R^M\)

A frase “\(\Theta\subset\mathbb R^M\)” é ambígua porque \(M\) já é a matriz de máscaras. Além disso, a dimensão do espaço de parâmetros não foi definida. Isso não quebra o argumento, mas é uma fonte desnecessária de confusão.

Referência no TeX enviado: linha 512.

Correção recomendada: usar \(p\) para a dimensão do espaço de parâmetros do template fixo: “Let \(p\) be the dimension of the chosen parameter space...”.

### 7. Critério genérico de mirror separation

O Remark sobre genericidade está conceitualmente aceitável, mas a frase “In particular, mirror separation holds for almost all...” deve ficar claramente condicionada ao critério de não-identidade dos discrepâncias. O texto já introduz esse critério; basta trocar “In particular” por “Under this non-identity criterion”.

Referência no TeX enviado: linha 540.

### 8. Exemplo: cálculo correto, mas uma frase deve ser ajustada

Eu verifiquei o exemplo de sete vértices. As máscaras, a matriz \(M\), a matriz \(V\), as condições \(a_4+a_5=0\) e \(a_6+a_{C_2}=0\), os postos \(\operatorname{rank}[M;V]=4\), \(\operatorname{rank}V=2\), e a contagem final \(2^{1+4-2}=8\) estão corretos.

A descrição geométrica também está correta, mas a apresentação “\(g_4\oplus g_5\oplus g_{C_2}\oplus g_6\)” deve ser explicada como apresentação redundante: o par \(g_{C_2}\oplus g_6\) cancela na projeção por máscaras. A operação geométrica efetiva do shift \(\{v_4,v_5,v_6\}\) é o bloco \(C_1\), representado por \(g_4\oplus g_5\) ou por \(g_{C_1}\).

Referência no TeX enviado: linha 816.

Também recomendo trocar “proving the rank-count theorem on a concrete geometric system” por “matching the rank-count prediction”, pois o exemplo ilustra/verifica o teorema nesse caso, mas não o prova.

Referência no TeX enviado: linha 826.

## O que está sólido

- A decomposição \(B=B_c\sqcup B_f\) é coerente: se um bit livre afetasse um endpoint de pruning, ele pertenceria ao fixing set desse endpoint e, portanto, estaria em \(L\).
- A matriz de máscaras \(M\) e a fórmula
  \[
  \dim M(\ker V)=\operatorname{rank}\begin{bmatrix}M\\V\end{bmatrix}-\operatorname{rank}(V)
  \]
  estão corretas por rank-nullity.
- A prova construtiva “\(h\in M(\ker V)\Rightarrow\)” preservação de arestas ativas fica consistente depois da restrição explícita ao subsistema ativo \(L\).
- A inclusão reversa do Teorema principal é logicamente correta sob a definição de mirror separation.
- O exemplo numérico realmente tem oito branch codes viáveis; a contagem bate com a fórmula.

## Recomendação

Aplicar o patch compacto antes de submeter. Ele preserva 17 páginas, compila limpo, não altera o teorema nem o exemplo, e remove os pontos em que um referee poderia alegar sobreafirmação ou imprecisão formal.
